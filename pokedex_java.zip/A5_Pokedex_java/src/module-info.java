/**
 * 
 */
/**
 * 
 */
module A5_Pokedex {
}