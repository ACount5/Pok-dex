package Pokedex;

public class EquipoPokemon {

    private Pokemon[] pokemons;
    private int cantidad;
    private final int MAX_POKEMON = 6;
    
    public EquipoPokemon() {
        pokemons = new Pokemon[MAX_POKEMON];
        cantidad = 0;
    }

    public void agregarPokemon(Pokemon p) {

        if (cantidad < 6) {
            pokemons[cantidad] = p;
            cantidad++;
        } else {
            System.out.println("El equipo ya tiene 6 pokemons.");
        }

    }

    public void mostrarEquipo() {

        System.out.println("Equipo Pokemon:");

        for (int i = 0; i < cantidad; i++) {
            System.out.println(pokemons[i].mostrarInfo());
        }

    }
}
