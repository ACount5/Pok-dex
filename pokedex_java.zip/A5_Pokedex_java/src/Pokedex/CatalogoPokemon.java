package Pokedex;
import java.util.ArrayList;

public class CatalogoPokemon implements Buscable {

    private ArrayList<Pokemon> pokemons;

    public CatalogoPokemon() {
        pokemons = new ArrayList<>();
    }

    public void agregarPokemon(Pokemon p) {
        pokemons.add(p);
    }

    @Override
    public Pokemon[] buscarPorNombre(String nombre) {

        ArrayList<Pokemon> resultado = new ArrayList<>();

        for (Pokemon p : pokemons) {
            if (p.getNombre().equalsIgnoreCase(nombre)) {
                resultado.add(p);
            }
        }

        return resultado.toArray(new Pokemon[0]);
    }

    @Override
    public Pokemon[] filtrarPorTipo(String tipo) {

        ArrayList<Pokemon> resultado = new ArrayList<>();

        for (Pokemon p : pokemons) {
            if (p.getTipo().equalsIgnoreCase(tipo)) {
                resultado.add(p);
            }
        }

        return resultado.toArray(new Pokemon[0]);
    }

    public void mostrarTodos() {

        for (Pokemon p : pokemons) {
            System.out.println(p.mostrarInfo());
        }

    }
}