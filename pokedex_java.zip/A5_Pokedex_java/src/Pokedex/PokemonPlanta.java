package Pokedex;

public class PokemonPlanta extends Pokemon {
	
		public PokemonPlanta(int numero, String nombre, int nivel, String habilidad) {
	        super(numero, nombre, nivel, "Planta", habilidad);
	    }
		
		
		@Override
		public void ataqueEspecial() {
			 System.out.println(nombre + " usa Hoja Afilada!");
		}
		

}
