package Pokedex;

public class Entrenador {

    private String nombre;
    private EquipoPokemon equipo;

    public Entrenador(String nombre) {
        this.nombre = nombre;
    }

    public void crearEquipo() {
        equipo = new EquipoPokemon();
    }

    public EquipoPokemon getEquipo() {
        return equipo;
    }
}