package Pokedex;

public abstract class Pokemon {
	 protected int numero;
	    protected String nombre;
	    protected int nivel;
	    protected String tipo;
	    protected String habilidad;

	    //constructor
	    public Pokemon(int numero, String nombre, int nivel, String tipo, String habilidad) {
	        this.numero = numero;
	        this.nombre = nombre;
	        this.nivel = nivel;
	        this.tipo = tipo;
	        this.habilidad = habilidad;
	    }

	    //getters and setters
	     public String getTipo() {
	        return tipo;
	    }

	    public int getNumero() {
			return numero;
		}

		public void setNumero(int numero) {
			this.numero = numero;
		}

		public String getNombre() {
			return nombre;
		}

		public void setNombre(String nombre) {
			this.nombre = nombre;
		}

		public int getNivel() {
			return nivel;
		}

		public void setNivel(int nivel) {
			this.nivel = nivel;
		}

		public String getHabilidad() {
			return habilidad;
		}

		public void setHabilidad(String habilidad) {
			this.habilidad = habilidad;
		}

		public void setTipo(String tipo) {
			this.tipo = tipo;
		}

		//métodos
		public String mostrarInfo() {
	        return "Numero: " + numero +
	                " Nombre: " + nombre +
	                " Nivel: " + nivel +
	                " Tipo: " + tipo +
	                " Habilidad: " + habilidad;
	    }


		public abstract void ataqueEspecial();
	}


