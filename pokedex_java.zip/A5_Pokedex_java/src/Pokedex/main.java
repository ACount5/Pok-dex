package Pokedex;

public class main {


	    public static void main(String[] args) {

	        CatalogoPokemon catalogo = new CatalogoPokemon();

	        Pokemon p1 = new PokemonFuego(4, "Charmander", 10, "Mar Llamas");
	        Pokemon p2 = new PokemonAgua(7, "Squirtle", 8, "Torrente");
	        Pokemon p3 = new PokemonPlanta(1, "Bulbasaur", 12,"Látigo Cepa");
	        

	        catalogo.agregarPokemon(p1);
	        catalogo.agregarPokemon(p2);
	        catalogo.agregarPokemon(p3);

	        catalogo.mostrarTodos();

	        Entrenador ash = new Entrenador("Ash");

	        ash.crearEquipo();

	        ash.getEquipo().agregarPokemon(p1);
	        ash.getEquipo().agregarPokemon(p2);
	        ash.getEquipo().agregarPokemon(p3);

	        ash.getEquipo().mostrarEquipo();
	    }
	}