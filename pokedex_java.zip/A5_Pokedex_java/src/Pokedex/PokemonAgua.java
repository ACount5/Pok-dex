package Pokedex;

public class PokemonAgua extends Pokemon {

    public PokemonAgua(int numero, String nombre, int nivel, String habilidad) {
        super(numero, nombre, nivel, "Agua", habilidad);
    }

    @Override
    public void ataqueEspecial() {
        System.out.println(nombre + " usa Hidrobomba!");
    }
}