package Pokedex;

public interface Buscable {
	 Pokemon[] buscarPorNombre(String nombre);

	    Pokemon[] filtrarPorTipo(String tipo);

}
