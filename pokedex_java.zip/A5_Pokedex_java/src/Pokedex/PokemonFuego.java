package Pokedex;

public class PokemonFuego extends Pokemon{
	
	
	public PokemonFuego(int numero, String nombre, int nivel, String habilidad) {
        super(numero, nombre, nivel, "Fuego", habilidad);
    }
	
	

	@Override
	public void ataqueEspecial() {
		 System.out.println(nombre + " usa Lanzallamas!");
	}
	
}
